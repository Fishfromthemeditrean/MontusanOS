extends Button
@onready var root = $"../"

func _on_pressed() -> void:
	root.queue_free()
