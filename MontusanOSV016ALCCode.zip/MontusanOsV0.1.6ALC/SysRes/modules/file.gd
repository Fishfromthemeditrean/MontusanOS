extends Node
## Copy the contents of a folder into a new folder, and return the new folders absolute path not my code i got it from the forums.
func copy_folder(folder_to_copy : String, new_folder_location : String, new_folder_name=null) -> String:
	new_folder_name = folder_to_copy.trim_suffix("/").get_file()
	# Handle path issues
	print("%s/%s" % [new_folder_location, new_folder_name])
	if DirAccess.dir_exists_absolute("%s/%s" % [new_folder_location, new_folder_name]):
		push_error("Dir already exists in destination!")
		return "err1"
	if not DirAccess.dir_exists_absolute(folder_to_copy):
		printerr("Invalid folder to copy '" + folder_to_copy + ".")
		return ""
	if not DirAccess.dir_exists_absolute(new_folder_location):
		printerr("Invalid copy location '" + new_folder_location + ".")
		return ""
	
	# Get new location contents, folders and files
	var copy_location_contents : PackedStringArray = DirAccess.get_directories_at(new_folder_location)
	copy_location_contents.append_array(DirAccess.get_files_at(new_folder_location))
	
	# Make new directory 
	var new_dir_path : String = new_folder_location + "/" + new_folder_name
	DirAccess.make_dir_absolute(new_dir_path)
	
	#Copy each file and folder into the new folder
	var old_files : PackedStringArray = DirAccess.get_files_at(folder_to_copy)
	for f : String in old_files:
		DirAccess.copy_absolute(folder_to_copy + "/" + f, new_dir_path + "/" + f)
	var old_directories : PackedStringArray = DirAccess.get_directories_at(folder_to_copy)
	for d : String in old_directories:
		copy_folder(d, folder_to_copy + "/" + d, new_dir_path)
	
	return new_dir_path

func outputfiles(dir):
	if dir:
		var CompletedArray: Array
		var f: Array = DirAccess.get_files_at(dir)
		for File in f:
			var ValueWPath = dir.path_join(File)
			CompletedArray.append(ValueWPath)
		return CompletedArray
 
func outputdirs(dir):
	#This is supposed to output directories in a directory with it's filepath... BUT IT JUST OUTOUTS ONEDIRECTORY THAT BEJNG THE FIRST ONE CREATED!!!!!!! hey... nvm. it works now ayyaaayayayyyaayaa6ayayaysyzgnxxuducjkd9dsfbrodppsmx
	if DirAccess.dir_exists_absolute(dir): #Checks if the directory exists or not.
		var CompletedArray: Array = []
		var darray: PackedStringArray = DirAccess.get_directories_at(dir) #Returns all directories in a directory WITHOUT it's filepath at the beginning. It returns the name of the directory.
		for Directory in darray: #iterates on the array "darray" adds it's path at the beginning puts it into CompletedArray and returns it when it's completed.
			var ValueWPath = dir.path_join(Directory)
			CompletedArray.append(ValueWPath)
		return CompletedArray
			
  
func newdir(path, dirname):
	#--Combines path and dirname to create fullpath--#
	var fullpath = "%s/%s" % [path, dirname]
	#--Checks if path exists and checks if fullpath doesn't already exist--#
	if DirAccess.dir_exists_absolute(path) and not DirAccess.dir_exists_absolute(fullpath):
		#--Create the directory--#
		DirAccess.make_dir_absolute(fullpath)
	else:
		#--Error Handling--#
		push_error("Directory may already exist or parent directory doesn't exist.")
		return 1
#----#
func newfile(path: String, filename: String, content: String = ""):
	#--Unifies path and filename--#
	var fullpath = "%s/%s" % [path, filename]
	#--Checks if the file doesn't already exist or if the parent directory exists.--#
	if DirAccess.dir_exists_absolute(path) and not FileAccess.file_exists(fullpath):
		#--Creates the file and writes to it--#
		var f = FileAccess.open(fullpath, FileAccess.WRITE)
		if f:
			f.store_string(content)
			f.close()
		else:
			#--Error Handling--# 
			push_error("Parent directory may not exist or file already exists.")
			return 1
func LoadPng(filepath: String):
	#--loads an image from ImageTexture--#
	var img = Image.new()
	var error = img.load(filepath)
	if error == OK:
		var texture = ImageTexture.create_from_image(img)
		return texture
	else:
		push_error("Couldn't load image.")
