extends Node
#--This helper script is responsible for retrieving and parsing manifests and then inputing the data into appinit--#
var instance: Node
var RealAppCount: int = 0
var AppCount: int = 0
var AppButton: TextureButton

func GetManifest(Path: String):
	#--Checks if the file exists--#
	if DirAccess.dir_exists_absolute(Path):
		var ManifestFound: bool = false
		#--Outputs every directory in the path provided by the user script--#
		for Dir in file.outputdirs(Path):
			ManifestFound = false
			#--Outputs every file in the path provided by the upper loop--#
			for f in file.outputfiles(Dir):
				if f.get_file() == "Manifest.json":
					ParseManifest(f)
					ManifestFound = true
					break
				else:continue
			if not ManifestFound:
				OS.alert("Manifest of %s not found." % [Dir], "Error while loading apps.")
				printerr("System crash 01LA when parsing manifest at AppPath %s" % [Dir])
				return null
	else:
		push_error("Dir not found.")
func ParseManifest(Manifest):
	if FileAccess.file_exists(Manifest):  #--Checks if the file exists--#
		#--Data & Error Handling--#
		var File = FileAccess.get_file_as_string(Manifest)
		var Json = JSON.new()
		var Error = Json.parse(File)
		var ActualJsonData
		#--Error Handling--#
		if Error != OK:
			push_error("The JSON file returned an integer meaning it has returned an error: error'%s' on line '%s' while processing '%s'" % [Json.get_error_message(), str(Json.get_error_line()), Manifest])
			return {}
		else:
			ActualJsonData = Json.data
			#--Turns a relative path to a full path for the appicon.--#
			var AppIconRelHelper = ActualJsonData["AppIcon"].trim_prefix("/$HOME")
			var AppIconFull = Manifest.get_base_dir().path_join(AppIconRelHelper)
			#--Does the Same thing but for MainActivity.--#
			var MainActHelper = ActualJsonData["MainActivity"].trim_prefix("/$HOME")
			var MainActFull = Manifest.get_base_dir().path_join(MainActHelper)
			appinit(ActualJsonData["AppName"], AppIconFull, MainActFull)
func appinit(AppName: String, AppIcon, WindowScene):
	#--Node definitions--#
	AppButton = TextureButton.new()
	var AppLabel = Label.new()
	
	#--Value assignation--#
	if RealAppCount !=  112:
		AppButton.texture_normal = file.LoadPng(AppIcon)
		AppLabel.text = AppName
		AppButton.position = globals.AppIconPosition
		globals.AppIconPosition.x += 96
		#Other stuff 
		AppButton.add_child(AppLabel)
		AppLabel.position = globals.AppLabelPosition
		globals.AppProcesses.add_child(AppButton)
		AppCount += 1
		RealAppCount += 1
		AppButton.pressed.connect(_MainAct.bind(load(WindowScene)))
	if RealAppCount == 112:
		if not instance:
			var AppOverload = preload("res://SysRes/Errors/AppLimit.tscn")
			instance = AppOverload.instantiate()
			get_tree().current_scene.add_child(instance)
			return
	if AppCount == 16:
		
		globals.AppIconPosition.y += 80
		globals.AppIconPosition.x = 24
		AppCount = 0
	
func _MainAct(AppScene):
	var Scene = AppScene.instantiate()
	globals.windows.add_child(Scene)
