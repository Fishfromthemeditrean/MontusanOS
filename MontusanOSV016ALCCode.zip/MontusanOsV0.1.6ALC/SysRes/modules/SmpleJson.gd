extends Node


func SaveDataToJson(file, data, thething=""):
	
	var datastr = JSON.stringify(data, thething)
	if not FileAccess.file_exists(file):
		push_error("file %s doesn't exist. Error: FileNotFound" % [file])
	else:
		var f = FileAccess.open(file, FileAccess.WRITE)
		f.store_string(datastr)
		f.close()
func LoadDataFromJson(file):
	if FileAccess.file_exists(file):
		var f = FileAccess.open(file, FileAccess.READ)
		var unc = f.get_as_text()
		var uc = JSON.parse_string(unc)
		f.close()
		return uc
	else:
		push_error("file doesn't exist. ")
