extends Button
@onready var novium = $"../Novium"

func _on_pressed() -> void:
	print("test")
	novium.visible = !novium.visible
