extends Control
func remove_recursive(path: String) -> void:
	var dir = DirAccess.open(path)
	if dir:
		dir.list_dir_begin()
		var file_name = dir.get_next()
		while file_name != "":
			if file_name != "." and file_name != "..":
				var full_path = path.path_join(file_name)
				if dir.current_is_dir():
					remove_recursive(full_path)
				else:
					dir.remove_absolute(full_path)
			file_name = dir.get_next()
		dir.list_dir_end()
		DirAccess.remove_absolute(path)
		
func CopyAppsToPrivateir():
	for App in file.outputdirs("user://apps"):
		remove_recursive(App)
func _ready() -> void:
	CopyAppsToPrivateDir()
func CopyAppsToPrivateDir():
	for App in file.outputdirs("/sdcard/MontusanOSDta/SystemApps"):
		file.copy_folder(App, "user://apps/")
		print(App)
	app.GetManifest("user://apps/")
