extends Node
var bg_col = Color("baacd8")
@onready var AppProcesses: Node
var AppIconPosition: Vector2 = Vector2(24.0, 16.0)
var AppLabelPosition: Vector2 = Vector2(0.0, 59.0)
var in_BIOS
var OSDataPath
var main_window
var windows: Node
func _ready() -> void:
	if DirAccess.dir_exists_absolute("/storage/emulated/0/MontusanOSDta"): OSDataPath = "/storage/emulated/0/MontusanOSDta"
	else:
		file.newdir("/storage/emulated/0", "MontusanOSDta")
		OSDataPath = "/storage/emulated/0/MontusanOSDta"
