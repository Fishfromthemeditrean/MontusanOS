extends ColorPickerButton

func _on_color_changed(color: Color) -> void:
	globals.bg_col = color

func _on_popup_closed() -> void:
	color = globals.bg_col
