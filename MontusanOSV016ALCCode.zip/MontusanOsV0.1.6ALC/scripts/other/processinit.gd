extends Node
func _ready() -> void:
	
	globals.AppProcesses = $"../"
	globals.in_BIOS = false
	globals.main_window = $"../../"
	globals.windows = $"../../windows"
