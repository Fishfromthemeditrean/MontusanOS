extends Node
func _ready():
	if not FileAccess.file_exists("/storage/emulated/0/loadedapps.json"):
		file.newfile("/storage/emulated/0", "loadedapps.json")
