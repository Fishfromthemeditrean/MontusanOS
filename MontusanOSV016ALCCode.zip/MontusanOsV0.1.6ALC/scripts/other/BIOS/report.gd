extends Label
func _ready():
	#--Executes these 2 functions--#
	CreateNecessaryDirs()
	AskPermissionsAndroid()
	#--Waits for 2.5s and then goes to the main scene--#
	await get_tree().create_timer(0).timeout
	get_tree().change_scene_to_file("res://main.tscn")

func CreateNecessaryDirs():
	#--Creates the public data & app directories--#
	if not DirAccess.dir_exists_absolute("/sdcard/MontusanOSDta"):
		#----#
		DirAccess.make_dir_absolute("/sdcard/MontusanOSDta")
		#----#
		DirAccess.make_dir_absolute("/sdcard/MontusanOSDta/SystemApps")
		#----#
		DirAccess.make_dir_absolute("/sdcard/MontusanOSDta/UserApps")
	#--Creates the app directory in the private sandboxed directory where scripts can be executed--#
	if not DirAccess.dir_exists_absolute("user://apps"):
		DirAccess.make_dir_absolute("user://apps")

func AskPermissionsAndroid():
	#--Asks for permissions on Android--#
	if OS.get_name() == "Android" and OS.get_granted_permissions().is_empty():
		OS.request_permissions()
		await get_tree().on_request_permissions_result

func Report(Text: String):
	#--Appends text to self--#
	self.text = "%s%s" % [self.text, Text]
